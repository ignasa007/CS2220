package Q6;

public class Q6 {

    public static void main(String[] args) {

        

    }

}